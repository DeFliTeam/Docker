"use strict";
var READSB;
(function (READSB) {
    document.addEventListener("DOMContentLoaded", READSB.AppSettings.ReadDefaultSettings.bind(READSB.AppSettings));
})(READSB || (READSB = {}));
//# sourceMappingURL=loader.js.map