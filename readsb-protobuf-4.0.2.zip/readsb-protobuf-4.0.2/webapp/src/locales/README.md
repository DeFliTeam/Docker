This web application uses I18next for internationalization.

Feel free to contribute in case your native language is not yet supported by translating
one of the already existing languages into your native one. e.g. Take a copy of `en.json` and use
the text editor of your choice to translate the text on the right side of all JSON variables
inside the file. Save the file with UTF-8 encoding.

When done just create a pull request to merge your translation into a corresponding branch.

Thanks in advance for your support.
